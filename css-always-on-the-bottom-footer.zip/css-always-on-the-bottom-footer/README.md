# CSS "Always on the bottom" Footer

A Pen created on CodePen.io. Original URL: [https://codepen.io/cbracco/pen/kQmVGM](https://codepen.io/cbracco/pen/kQmVGM).

Using CSS, this footer rests at the bottom of the page, even if the content above it is too short to push it to the bottom of the viewport naturally. However, if the content is taller than the user’s viewport, then the footer disappears from view as it would normally, resting at the bottom of the page (not fixed).